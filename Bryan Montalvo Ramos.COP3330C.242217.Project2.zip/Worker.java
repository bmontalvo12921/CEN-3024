public interface Worker {// used to set up different "work" services
    void oilchange(Vehicle vehicle);
    void brakejob(Vehicle vehicle);
    void Bills(Vehicle vehicle);

}// interface that establishes the type of "work"
