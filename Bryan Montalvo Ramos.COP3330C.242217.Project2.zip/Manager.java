public interface Manager {
    void manage();
}//established Manager
