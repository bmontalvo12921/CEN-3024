    //Interface to establish different Vehicle Classes
public interface Vehicleclass {
   //Attributes to define Vehicle class
    void Car();
    void Motorcycle();
}
